-- ============================================================
-- FiveM Auto Error Handler - Server Error Handler Engine
-- Author: Manus AI
-- ============================================================

local ErrorLog = {}
local ResourceRestartCount = {}
local ResourceLastRestart = {}

-- ============================================================
-- 核心錯誤記錄函數
-- ============================================================

--- 記錄一筆錯誤到日誌系統
--- @param errorData table 錯誤資料物件
function LogError(errorData)
    if not errorData then return end

    -- 加入錯誤日誌
    table.insert(ErrorLog, 1, errorData) -- 最新的在最前面

    -- 限制日誌最大筆數 (防止記憶體溢出)
    if #ErrorLog > 500 then
        table.remove(ErrorLog, #ErrorLog)
    end

    -- 輸出到伺服器控制台
    local severityLabel = ('[' .. string.upper(errorData.severity or 'UNKNOWN') .. ']')
    print(string.format(
        '^1[ErrorHandler]^7 %s ^3[%s]^7 Resource: ^5%s^7 | %s',
        severityLabel,
        errorData.type or 'UNKNOWN',
        errorData.resource or 'unknown',
        errorData.message or 'No message'
    ))

    -- 觸發 Discord Webhook 推播
    if Config.Webhook.Enabled then
        TriggerEvent('errorhandler:sendWebhook', errorData)
    end

    -- 廣播給所有已連線的管理員客戶端
    TriggerEvent('errorhandler:broadcastToAdmins', errorData)
end

-- ============================================================
-- 取得錯誤日誌 (供 NUI 查詢)
-- ============================================================

RegisterNetEvent('errorhandler:getErrorLog', function()
    local src = source
    if not IsPlayerAdmin(src) then return end

    TriggerClientEvent('errorhandler:receiveErrorLog', src, ErrorLog)
end)

-- ============================================================
-- 清除錯誤日誌
-- ============================================================

RegisterNetEvent('errorhandler:clearLog', function()
    local src = source
    if not IsPlayerAdmin(src) then return end

    ErrorLog = {}
    TriggerClientEvent('errorhandler:logCleared', src)
    print('^2[ErrorHandler]^7 錯誤日誌已由管理員清除。')
end)

-- ============================================================
-- 標記錯誤為已修復
-- ============================================================

RegisterNetEvent('errorhandler:markFixed', function(errorId)
    local src = source
    if not IsPlayerAdmin(src) then return end

    for _, err in ipairs(ErrorLog) do
        if err.id == errorId then
            err.fixed = true
            err.fixedAt = Utils.GetTimestamp()
            break
        end
    end

    TriggerClientEvent('errorhandler:receiveErrorLog', src, ErrorLog)
end)

-- ============================================================
-- 廣播錯誤給管理員
-- ============================================================

AddEventHandler('errorhandler:broadcastToAdmins', function(errorData)
    local players = GetPlayers()
    for _, playerId in ipairs(players) do
        local pid = tonumber(playerId)
        if IsPlayerAdmin(pid) then
            TriggerClientEvent('errorhandler:newError', pid, errorData)
        end
    end
end)

-- ============================================================
-- 取得統計資料
-- ============================================================

RegisterNetEvent('errorhandler:getStats', function()
    local src = source
    if not IsPlayerAdmin(src) then return end

    local stats = {
        total = #ErrorLog,
        critical = 0,
        high = 0,
        medium = 0,
        low = 0,
        fixed = 0
    }

    for _, err in ipairs(ErrorLog) do
        if err.severity == 'critical' then stats.critical = stats.critical + 1
        elseif err.severity == 'high' then stats.high = stats.high + 1
        elseif err.severity == 'medium' then stats.medium = stats.medium + 1
        elseif err.severity == 'low' then stats.low = stats.low + 1
        end
        if err.fixed then stats.fixed = stats.fixed + 1 end
    end

    TriggerClientEvent('errorhandler:receiveStats', src, stats)
end)

-- ============================================================
-- 取得資源重啟記錄
-- ============================================================

function GetResourceRestartInfo(resourceName)
    return {
        count = ResourceRestartCount[resourceName] or 0,
        lastRestart = ResourceLastRestart[resourceName] or 'Never'
    }
end

-- 更新重啟記錄
function UpdateRestartRecord(resourceName)
    ResourceRestartCount[resourceName] = (ResourceRestartCount[resourceName] or 0) + 1
    ResourceLastRestart[resourceName] = Utils.GetTimestamp()
end
