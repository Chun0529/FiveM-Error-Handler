-- ============================================================
-- FiveM Auto Error Handler - Shared Utilities
-- Author: Manus AI
-- ============================================================

Utils = {}

-- 取得當前時間戳記 (格式化字串)
function Utils.GetTimestamp()
    return os.date('%Y-%m-%d %H:%M:%S')
end

-- 取得當前 Unix 時間戳記 (毫秒)
function Utils.GetCurrentTime()
    return os.time() * 1000
end

-- 安全的 JSON 編碼 (防止崩潰)
function Utils.SafeEncode(data)
    local ok, result = pcall(json.encode, data)
    if ok then
        return result
    else
        return '{"error":"JSON encode failed"}'
    end
end

-- 安全的 JSON 解碼
function Utils.SafeDecode(str)
    if not str or str == '' then return nil end
    local ok, result = pcall(json.decode, str)
    if ok then
        return result
    else
        return nil
    end
end

-- 截斷過長的字串
function Utils.Truncate(str, maxLen)
    if not str then return 'N/A' end
    maxLen = maxLen or 200
    if #str > maxLen then
        return str:sub(1, maxLen) .. '...'
    end
    return str
end

-- 格式化錯誤訊息
function Utils.FormatError(errorType, resourceName, message, severity)
    return {
        id = tostring(math.random(100000, 999999)),
        type = errorType or 'UNKNOWN',
        resource = resourceName or 'unknown',
        message = Utils.Truncate(message, 500),
        severity = severity or 'medium', -- low, medium, high, critical
        timestamp = Utils.GetTimestamp(),
        fixed = false
    }
end

-- 嚴重程度顏色對應
Utils.SeverityColors = {
    low = '#27ae60',
    medium = '#f39c12',
    high = '#e67e22',
    critical = '#e74c3c'
}

-- 錯誤類型標籤
Utils.ErrorTypes = {
    LUA_RUNTIME = 'Lua 執行錯誤',
    RESOURCE_CRASH = '資源崩潰',
    DATABASE_ERROR = '資料庫錯誤',
    NETWORK_SYNC = '網路同步錯誤',
    ENTITY_ERROR = '實體錯誤',
    TIMEOUT = '逾時錯誤',
    CONFIG_ERROR = '設定錯誤'
}
