-- ============================================================
-- FiveM Auto Error Handler - Client Main
-- Author: Manus AI
-- ============================================================

local IsPanelOpen = false

-- ============================================================
-- 面板開啟/關閉
-- ============================================================

RegisterNetEvent('errorhandler:openPanel', function()
    if IsPanelOpen then return end
    IsPanelOpen = true

    -- 顯示 NUI
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open'
    })

    -- 請求初始資料
    TriggerServerEvent('errorhandler:getErrorLog')
    TriggerServerEvent('errorhandler:getStats')
    TriggerServerEvent('errorhandler:getResourceList')
end)

-- 關閉面板
RegisterNUICallback('closePanel', function(data, cb)
    IsPanelOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({
        action = 'close'
    })
    cb({ ok = true })
end)

-- ESC 鍵關閉面板
CreateThread(function()
    while true do
        Wait(0)
        if IsPanelOpen and IsControlJustReleased(0, 322) then -- ESC
            IsPanelOpen = false
            SetNuiFocus(false, false)
            SendNUIMessage({ action = 'close' })
        end
    end
end)

-- ============================================================
-- 接收錯誤日誌
-- ============================================================

RegisterNetEvent('errorhandler:receiveErrorLog', function(errorLog)
    SendNUIMessage({
        action = 'updateErrorLog',
        data = errorLog
    })
end)

-- ============================================================
-- 接收統計資料
-- ============================================================

RegisterNetEvent('errorhandler:receiveStats', function(stats)
    SendNUIMessage({
        action = 'updateStats',
        data = stats
    })
end)

-- ============================================================
-- 接收資源清單
-- ============================================================

RegisterNetEvent('errorhandler:receiveResourceList', function(resourceList)
    SendNUIMessage({
        action = 'updateResourceList',
        data = resourceList
    })
end)

-- ============================================================
-- 新錯誤通知 (即時推播)
-- ============================================================

RegisterNetEvent('errorhandler:newError', function(errorData)
    -- 如果面板開啟，更新顯示
    if IsPanelOpen then
        SendNUIMessage({
            action = 'newError',
            data = errorData
        })
    end

    -- 顯示遊戲內通知
    local severity = errorData.severity or 'medium'
    if severity == 'critical' or severity == 'high' then
        SetNotificationTextEntry('STRING')
        AddTextComponentString(string.format(
            '~r~[錯誤警報]~w~ %s\n資源: %s',
            errorData.type or 'ERROR',
            errorData.resource or 'unknown'
        ))
        DrawNotification(false, true)
    end
end)

-- ============================================================
-- 日誌清除確認
-- ============================================================

RegisterNetEvent('errorhandler:logCleared', function()
    SendNUIMessage({ action = 'logCleared' })
end)

-- ============================================================
-- 通知訊息
-- ============================================================

RegisterNetEvent('errorhandler:notification', function(message, notifType)
    SendNUIMessage({
        action = 'notification',
        message = message,
        notifType = notifType or 'info'
    })
end)

-- ============================================================
-- NUI 回調 - 請求資料刷新
-- ============================================================

RegisterNUICallback('refreshData', function(data, cb)
    TriggerServerEvent('errorhandler:getErrorLog')
    TriggerServerEvent('errorhandler:getStats')
    TriggerServerEvent('errorhandler:getResourceList')
    cb({ ok = true })
end)

-- NUI 回調 - 清除日誌
RegisterNUICallback('clearLog', function(data, cb)
    TriggerServerEvent('errorhandler:clearLog')
    cb({ ok = true })
end)

-- NUI 回調 - 標記已修復
RegisterNUICallback('markFixed', function(data, cb)
    TriggerServerEvent('errorhandler:markFixed', data.id)
    cb({ ok = true })
end)

-- NUI 回調 - 重啟資源
RegisterNUICallback('restartResource', function(data, cb)
    TriggerServerEvent('errorhandler:restartResource', data.resourceName)
    cb({ ok = true })
end)

-- NUI 回調 - 清除問題實體
RegisterNUICallback('clearEntities', function(data, cb)
    TriggerServerEvent('errorhandler:clearProblematicEntities')
    cb({ ok = true })
end)

-- NUI 回調 - 測試 Webhook
RegisterNUICallback('testWebhook', function(data, cb)
    TriggerServerEvent('errorhandler:testWebhook')
    cb({ ok = true })
end)
