-- ============================================================
-- FiveM Auto Error Handler - Discord Webhook Module
-- Author: Manus AI
-- ============================================================

-- 嚴重程度對應的 Discord 顏色 (十進位)
local SeverityDiscordColors = {
    low = 3066993,      -- 綠色
    medium = 16776960,  -- 黃色
    high = 16744272,    -- 橘色
    critical = 15158332 -- 紅色
}

-- 嚴重程度對應的 Emoji
local SeverityEmoji = {
    low = '🟢',
    medium = '🟡',
    high = '🟠',
    critical = '🔴'
}

-- ============================================================
-- 發送 Discord Webhook
-- ============================================================

--- 發送錯誤通知到 Discord
--- @param errorData table 錯誤資料物件
local function SendDiscordWebhook(errorData)
    if not Config.Webhook.Enabled then return end
    if not Config.Webhook.URL or Config.Webhook.URL == 'YOUR_DISCORD_WEBHOOK_URL_HERE' then
        return
    end

    local severity = errorData.severity or 'medium'
    local color = SeverityDiscordColors[severity] or SeverityDiscordColors.medium
    local emoji = SeverityEmoji[severity] or '⚪'

    -- 建立 Discord Embed 訊息
    local embed = {
        {
            title = string.format('%s FiveM 伺服器錯誤警報', emoji),
            description = string.format('**錯誤 ID:** `%s`', errorData.id or 'N/A'),
            color = color,
            fields = {
                {
                    name = '📋 錯誤類型',
                    value = string.format('`%s`', errorData.type or 'UNKNOWN'),
                    inline = true
                },
                {
                    name = '⚠️ 嚴重程度',
                    value = string.format('`%s`', string.upper(severity)),
                    inline = true
                },
                {
                    name = '📦 資源名稱',
                    value = string.format('`%s`', errorData.resource or 'unknown'),
                    inline = true
                },
                {
                    name = '💬 錯誤訊息',
                    value = string.format('```\n%s\n```', Utils.Truncate(errorData.message, 1000)),
                    inline = false
                },
                {
                    name = '🕐 發生時間',
                    value = errorData.timestamp or 'N/A',
                    inline = true
                },
                {
                    name = '🔧 自動修復',
                    value = errorData.fixed and '✅ 已修復' or '❌ 待處理',
                    inline = true
                }
            },
            footer = {
                text = 'FiveM Auto Error Handler v1.0.0 | Powered by Manus AI'
            },
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ')
        }
    }

    local payload = Utils.SafeEncode({
        username = Config.Webhook.BotName or 'FiveM Error Monitor',
        avatar_url = Config.Webhook.AvatarURL,
        embeds = embed
    })

    -- 使用 PerformHttpRequest 發送 Webhook
    PerformHttpRequest(Config.Webhook.URL, function(statusCode, response, headers)
        if statusCode ~= 200 and statusCode ~= 204 then
            print(string.format(
                '^1[ErrorHandler]^7 Discord Webhook 發送失敗！狀態碼: %s',
                tostring(statusCode)
            ))
        end
    end, 'POST', payload, {
        ['Content-Type'] = 'application/json'
    })
end

-- ============================================================
-- 事件監聽
-- ============================================================

AddEventHandler('errorhandler:sendWebhook', function(errorData)
    -- 僅對 medium 以上嚴重程度發送 Webhook
    local severity = errorData.severity or 'medium'
    if severity == 'low' then return end

    SendDiscordWebhook(errorData)
end)

-- ============================================================
-- 測試 Webhook 指令 (管理員使用)
-- ============================================================

RegisterNetEvent('errorhandler:testWebhook', function()
    local src = source
    if not IsPlayerAdmin(src) then return end

    local testError = Utils.FormatError(
        'LUA_RUNTIME',
        GetCurrentResourceName(),
        '這是一條測試 Webhook 訊息，用於驗證 Discord 通知功能是否正常運作。',
        'medium'
    )

    SendDiscordWebhook(testError)
    TriggerClientEvent('errorhandler:notification', src, '已發送測試 Webhook！請檢查 Discord 頻道。', 'success')
    print('^2[ErrorHandler]^7 管理員 [' .. GetPlayerName(tostring(src)) .. '] 發送了測試 Webhook。')
end)
