fx_version 'cerulean'
game 'gta5'

author 'Manus AI'
description 'FiveM Auto Error Handler & Fixer with NUI Dashboard'
version '1.0.0'

-- UI Configuration
ui_page 'html/index.html'

-- Shared Scripts (Config, Locales, Utils)
shared_scripts {
    '@oxmysql/lib/MySQL.lua',
    'shared/config.lua',
    'shared/utils.lua'
}

-- Client Scripts
client_scripts {
    'client/main.lua',
    'client/nui.lua',
    'client/error_catcher.lua'
}

-- Server Scripts
server_scripts {
    'server/main.lua',
    'server/webhook.lua',
    'server/resource_monitor.lua',
    'server/error_handler.lua'
}

-- NUI Files
files {
    'html/index.html',
    'html/css/style.css',
    'html/js/app.js'
}

-- Lua 5.4 Support
lua54 'yes'
