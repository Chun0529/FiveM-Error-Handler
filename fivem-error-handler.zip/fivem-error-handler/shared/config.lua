-- ============================================================
-- FiveM Auto Error Handler - Configuration File
-- Author: Manus AI
-- Version: 1.0.0
-- ============================================================

Config = {}

-- ============================================================
-- 框架設定
-- 支援值: 'auto' | 'esx' | 'qbcore' | 'qbx' | 'standalone'
-- 'auto' 會自動偵測已安裝的框架
-- ============================================================
Config.Framework = 'auto'

-- ============================================================
-- 權限設定
-- ============================================================
Config.Permissions = {
    -- 是否使用 ACE Permissions 進行權限驗證
    -- 若為 true，玩家需要有 'errorhandler.admin' 或 'command.errorpanel' 的 ACE 權限
    -- 若為 false，則依賴框架的管理員群組 (ESX: admin/superadmin, QBCore: admin/god)
    UseAce = true,

    -- ACE 權限群組 (在 server.cfg 中設定)
    -- 範例: add_ace group.admin errorhandler.admin allow
    AceGroup = 'group.admin',

    -- 開啟控制面板的指令名稱
    CommandName = 'errorpanel'
}

-- ============================================================
-- Discord Webhook 設定
-- ============================================================
Config.Webhook = {
    -- 是否啟用 Discord Webhook 推播
    Enabled = true,

    -- Discord Webhook URL (在 Discord 頻道設定中建立)
    -- 格式: https://discord.com/api/webhooks/XXXXXXXXXX/XXXXXXXXXX
    URL = '',

    -- Webhook 機器人名稱
    BotName = 'FiveM Error Monitor',

    -- Webhook 機器人頭像 URL (可選)
    AvatarURL = 'https://i.imgur.com/7b2o2tM.png',

    -- 僅推播此嚴重程度以上的錯誤
    -- 可選值: 'low' | 'medium' | 'high' | 'critical'
    MinSeverity = 'medium',

    -- Embed 顏色 (十進位，預設紅色)
    Color = 15158332
}

-- ============================================================
-- 自動修復設定
-- ============================================================
Config.AutoFix = {
    -- 是否自動重啟崩潰的資源
    RestartCrashedResources = true,

    -- 是否自動清除問題實體 (無效車輛、NPC、物件)
    ClearProblematicEntities = true,

    -- 資源最大自動重啟次數
    -- 超過此次數後停止自動重啟，並發送 critical 警告
    MaxRestartAttempts = 3,

    -- 資源重啟冷卻時間 (毫秒)
    -- 建議不低於 30000 (30秒) 以避免無限重啟迴圈
    RestartCooldown = 60000,

    -- 不自動重啟的資源白名單 (這些資源崩潰時只記錄，不重啟)
    RestartBlacklist = {
        'monitor',
        'txAdmin',
        'mapmanager',
        'spawnmanager',
        'sessionmanager'
    }
}

-- ============================================================
-- 監控設定
-- ============================================================
Config.Monitor = {
    -- 資源健康檢查間隔 (毫秒)
    CheckInterval = 5000,

    -- 是否記錄資料庫錯誤 (oxmysql / mysql-async)
    LogDatabaseErrors = true,

    -- 是否記錄網路同步錯誤 (玩家逾時等)
    LogNetworkErrors = true,

    -- 是否捕捉客戶端 Lua 執行錯誤
    CatchClientErrors = true,

    -- 是否在遊戲內通知管理員新的 high/critical 錯誤
    InGameNotifications = true
}

-- ============================================================
-- 日誌設定
-- ============================================================
Config.Log = {
    -- 最大錯誤日誌保留筆數
    MaxEntries = 500,

    -- 是否在伺服器控制台輸出詳細日誌
    VerboseConsole = true
}
