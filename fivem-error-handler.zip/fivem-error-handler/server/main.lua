-- ============================================================
-- FiveM Auto Error Handler - Server Main
-- Author: Manus AI
-- ============================================================

-- ============================================================
-- 框架偵測與初始化
-- ============================================================

local Framework = nil

CreateThread(function()
    Wait(500)

    -- 自動偵測框架
    if Config.Framework == 'auto' or Config.Framework == 'esx' then
        if GetResourceState('es_extended') == 'started' then
            Framework = exports['es_extended']:getSharedObject()
            Config.Framework = 'esx'
            print('^2[ErrorHandler]^7 已偵測並整合 ESX 框架。')
        end
    end

    if Config.Framework == 'auto' or Config.Framework == 'qbcore' then
        if GetResourceState('qb-core') == 'started' then
            Framework = exports['qb-core']:GetCoreObject()
            Config.Framework = 'qbcore'
            print('^2[ErrorHandler]^7 已偵測並整合 QBCore 框架。')
        end
    end

    if Config.Framework == 'auto' or Config.Framework == 'qbx' then
        if GetResourceState('qbx_core') == 'started' then
            Framework = exports['qbx_core']:GetCoreObject()
            Config.Framework = 'qbx'
            print('^2[ErrorHandler]^7 已偵測並整合 QBX Core 框架。')
        end
    end

    if not Framework then
        Config.Framework = 'standalone'
        print('^3[ErrorHandler]^7 未偵測到框架，使用 ACE Permissions 獨立模式。')
    end

    print('^2[ErrorHandler]^7 ✅ 伺服器端初始化完成！框架: ' .. Config.Framework)
end)

-- ============================================================
-- 權限驗證函數
-- ============================================================

--- 檢查玩家是否為管理員
--- @param playerId number 玩家伺服器 ID
--- @return boolean
function IsPlayerAdmin(playerId)
    if not playerId or playerId <= 0 then return false end

    local pid = tostring(playerId)

    -- ACE Permissions 檢查 (最優先)
    if Config.Permissions.UseAce then
        if IsPlayerAceAllowed(pid, 'errorhandler.admin') then
            return true
        end
        if IsPlayerAceAllowed(pid, 'command.' .. Config.Permissions.CommandName) then
            return true
        end
    end

    -- ESX 框架權限
    if Config.Framework == 'esx' and Framework then
        local xPlayer = Framework.GetPlayerFromId(playerId)
        if xPlayer then
            local group = xPlayer.getGroup()
            return group == 'admin' or group == 'superadmin'
        end
    end

    -- QBCore 框架權限
    if (Config.Framework == 'qbcore' or Config.Framework == 'qbx') and Framework then
        local Player = Framework.Functions.GetPlayer(playerId)
        if Player then
            local permission = Player.PlayerData.permission
            return permission == 'admin' or permission == 'god'
        end
    end

    return false
end

-- ============================================================
-- 玩家連線事件 - 偵測框架玩家資料
-- ============================================================

AddEventHandler('playerConnecting', function(playerName, setKickReason, deferrals)
    local src = source
    -- 記錄玩家連線 (可選)
end)

-- ============================================================
-- 資料庫錯誤偵測 (oxmysql 整合)
-- ============================================================

if Config.Monitor.LogDatabaseErrors then
    -- 監聽 oxmysql 錯誤事件
    AddEventHandler('oxmysql:error', function(err)
        local errorData = Utils.FormatError(
            'DATABASE_ERROR',
            'oxmysql',
            tostring(err),
            'high'
        )
        LogError(errorData)
    end)

    -- 監聽 mysql-async 錯誤事件 (相容舊版)
    AddEventHandler('mysql:error', function(err)
        local errorData = Utils.FormatError(
            'DATABASE_ERROR',
            'mysql-async',
            tostring(err),
            'high'
        )
        LogError(errorData)
    end)
end

-- ============================================================
-- 網路同步錯誤偵測
-- ============================================================

if Config.Monitor.LogNetworkErrors then
    -- 監聽玩家逾時
    AddEventHandler('playerDropped', function(reason)
        local src = source
        if reason and (
            reason:find('timeout') or
            reason:find('Timed out') or
            reason:find('connection lost')
        ) then
            local errorData = Utils.FormatError(
                'NETWORK_SYNC',
                'server',
                string.format(
                    '玩家 [%s] (ID: %s) 因網路問題斷線: %s',
                    GetPlayerName(tostring(src)) or 'Unknown',
                    tostring(src),
                    reason
                ),
                'low'
            )
            LogError(errorData)
        end
    end)
end

-- ============================================================
-- 伺服器端 Lua 錯誤捕捉
-- ============================================================

-- 捕捉來自客戶端回報的 Lua 錯誤
RegisterNetEvent('errorhandler:reportClientError', function(errorMsg, resourceName)
    local src = source
    local errorData = Utils.FormatError(
        'LUA_RUNTIME',
        resourceName or 'unknown',
        string.format('[Client:%s] %s', tostring(src), errorMsg),
        'high'
    )
    LogError(errorData)
end)

-- 捕捉伺服器端 Lua 錯誤 (透過 pcall 包裝的事件)
RegisterNetEvent('errorhandler:reportServerError', function(errorMsg, resourceName)
    local src = source
    if not IsPlayerAdmin(src) then return end

    local errorData = Utils.FormatError(
        'LUA_RUNTIME',
        resourceName or 'server',
        errorMsg,
        'high'
    )
    LogError(errorData)
end)

-- ============================================================
-- 玩家指令 - 開啟控制面板
-- ============================================================

RegisterCommand(Config.Permissions.CommandName, function(source, args, rawCommand)
    local src = source

    if src == 0 then -- 伺服器控制台
        print('[ErrorHandler] 控制台無法開啟 NUI 面板。')
        return
    end

    if not IsPlayerAdmin(src) then
        TriggerClientEvent('errorhandler:notification', src, '您沒有權限使用此指令！', 'error')
        return
    end

    TriggerClientEvent('errorhandler:openPanel', src)
end, false)

-- ============================================================
-- 啟動訊息
-- ============================================================

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        print('^2[ErrorHandler]^7 ================================================')
        print('^2[ErrorHandler]^7  FiveM Auto Error Handler v1.0.0 已啟動！')
        print('^2[ErrorHandler]^7  指令: /' .. Config.Permissions.CommandName)
        print('^2[ErrorHandler]^7 ================================================')
    end
end)
