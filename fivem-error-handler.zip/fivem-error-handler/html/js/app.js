/* ============================================================
   FiveM Auto Error Handler - NUI JavaScript Application
   Author: Manus AI
   ============================================================ */

'use strict';

// ============================================================
// 應用程式狀態
// ============================================================

const App = {
    errorLog: [],
    resourceList: [],
    stats: { total: 0, critical: 0, high: 0, medium: 0, low: 0, fixed: 0 },
    currentTab: 'dashboard',
    selectedErrorId: null,
    filters: {
        errorSearch: '',
        severity: 'all',
        type: 'all',
        resourceSearch: '',
        resourceState: 'all'
    }
};

// ============================================================
// 工具函數
// ============================================================

function getParentResourceName() {
    return window.GetParentResourceName ? window.GetParentResourceName() : 'fivem-error-handler';
}

async function nuiCallback(name, data = {}) {
    try {
        const resp = await fetch(`https://${getParentResourceName()}/${name}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=UTF-8' },
            body: JSON.stringify(data)
        });
        return await resp.json();
    } catch (e) {
        console.error(`[ErrorHandler] NUI Callback error (${name}):`, e);
        return null;
    }
}

function formatTime(timestamp) {
    if (!timestamp) return '--';
    return timestamp;
}

function truncate(str, maxLen = 80) {
    if (!str) return 'N/A';
    return str.length > maxLen ? str.substring(0, maxLen) + '...' : str;
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// ============================================================
// 嚴重程度標籤渲染
// ============================================================

const SEVERITY_LABELS = {
    critical: { text: '🔴 嚴重', class: 'critical' },
    high:     { text: '🟠 高危', class: 'high' },
    medium:   { text: '🟡 中等', class: 'medium' },
    low:      { text: '🟢 低危', class: 'low' }
};

const ERROR_TYPE_LABELS = {
    LUA_RUNTIME:    'Lua 執行錯誤',
    RESOURCE_CRASH: '資源崩潰',
    DATABASE_ERROR: '資料庫錯誤',
    NETWORK_SYNC:   '網路同步',
    ENTITY_ERROR:   '實體錯誤',
    TIMEOUT:        '逾時錯誤',
    CONFIG_ERROR:   '設定錯誤'
};

const ERROR_TYPE_COLORS = {
    LUA_RUNTIME:    '#f85149',
    RESOURCE_CRASH: '#db6d28',
    DATABASE_ERROR: '#bc8cff',
    NETWORK_SYNC:   '#58a6ff',
    ENTITY_ERROR:   '#d29922',
    TIMEOUT:        '#8b949e',
    CONFIG_ERROR:   '#3fb950'
};

function renderSeverityBadge(severity) {
    const s = SEVERITY_LABELS[severity] || { text: severity, class: 'medium' };
    return `<span class="severity-badge ${s.class}">${s.text}</span>`;
}

function renderStateBadge(state) {
    const stateMap = {
        started:  { text: '✅ 運行中', class: 'started' },
        stopped:  { text: '❌ 已停止', class: 'stopped' },
        starting: { text: '🔄 啟動中', class: 'starting' },
        stopping: { text: '⏹️ 停止中', class: 'stopping' },
        missing:  { text: '❓ 找不到', class: 'stopped' }
    };
    const s = stateMap[state] || { text: state, class: 'stopped' };
    return `<span class="state-badge ${s.class}">${s.text}</span>`;
}

function renderFixBadge(fixed) {
    return fixed
        ? `<span class="fix-badge fixed">✅ 已修復</span>`
        : `<span class="fix-badge pending">⏳ 待處理</span>`;
}

// ============================================================
// 通知系統
// ============================================================

function showNotification(message, type = 'info') {
    const container = document.getElementById('notification-container');
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };

    const notif = document.createElement('div');
    notif.className = `notification ${type}`;
    notif.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${escapeHtml(message)}</span>`;

    container.appendChild(notif);

    setTimeout(() => {
        notif.classList.add('removing');
        setTimeout(() => notif.remove(), 300);
    }, 3500);
}

// ============================================================
// 標籤頁切換
// ============================================================

const PAGE_TITLES = {
    dashboard: '儀表板',
    errors: '錯誤日誌',
    resources: '資源監控',
    autofix: '自動修復',
    settings: '設定'
};

function switchTab(tabName) {
    // 更新導覽按鈕
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabName);
    });

    // 更新內容區
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.toggle('active', tab.id === `tab-${tabName}`);
    });

    // 更新頁面標題
    document.getElementById('page-title').textContent = PAGE_TITLES[tabName] || tabName;
    App.currentTab = tabName;
}

// ============================================================
// 更新統計資料
// ============================================================

function updateStats(stats) {
    App.stats = stats;
    document.getElementById('stat-total').textContent = stats.total || 0;
    document.getElementById('stat-critical').textContent = stats.critical || 0;
    document.getElementById('stat-high').textContent = stats.high || 0;
    document.getElementById('stat-fixed').textContent = stats.fixed || 0;

    // 更新錯誤徽章
    const unresolved = (stats.total || 0) - (stats.fixed || 0);
    const badge = document.getElementById('error-badge');
    badge.textContent = unresolved;
    badge.classList.toggle('hidden', unresolved === 0);
}

// ============================================================
// 更新錯誤日誌
// ============================================================

function updateErrorLog(errorLog) {
    App.errorLog = errorLog || [];
    renderDashboardErrors();
    renderErrorList();
    renderFixHistory();
    renderErrorChart();
    updateLastUpdate();
}

function renderDashboardErrors() {
    const tbody = document.getElementById('dashboard-error-list');
    const recent = App.errorLog.slice(0, 10);

    if (recent.length === 0) {
        tbody.innerHTML = `<tr class="empty-row"><td colspan="6">尚無錯誤記錄 ✨</td></tr>`;
        return;
    }

    tbody.innerHTML = recent.map(err => `
        <tr onclick="openErrorModal('${escapeHtml(err.id)}')">
            <td>${renderSeverityBadge(err.severity)}</td>
            <td><span class="text-mono">${escapeHtml(ERROR_TYPE_LABELS[err.type] || err.type)}</span></td>
            <td><code>${escapeHtml(err.resource)}</code></td>
            <td><span class="msg-truncate" title="${escapeHtml(err.message)}">${escapeHtml(truncate(err.message))}</span></td>
            <td><span class="text-muted">${formatTime(err.timestamp)}</span></td>
            <td>${renderFixBadge(err.fixed)}</td>
        </tr>
    `).join('');
}

function renderErrorList() {
    const tbody = document.getElementById('error-list');
    const filtered = filterErrors();

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr class="empty-row"><td colspan="8">沒有符合條件的錯誤記錄</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(err => `
        <tr onclick="openErrorModal('${escapeHtml(err.id)}')">
            <td><span class="text-mono text-muted">#${escapeHtml(err.id)}</span></td>
            <td>${renderSeverityBadge(err.severity)}</td>
            <td><span class="text-mono">${escapeHtml(ERROR_TYPE_LABELS[err.type] || err.type)}</span></td>
            <td><code>${escapeHtml(err.resource)}</code></td>
            <td><span class="msg-truncate" title="${escapeHtml(err.message)}">${escapeHtml(truncate(err.message))}</span></td>
            <td><span class="text-muted">${formatTime(err.timestamp)}</span></td>
            <td>${renderFixBadge(err.fixed)}</td>
            <td>
                ${!err.fixed ? `<button class="btn btn-success btn-sm" onclick="event.stopPropagation(); markFixed('${escapeHtml(err.id)}')">✅ 修復</button>` : ''}
            </td>
        </tr>
    `).join('');
}

function filterErrors() {
    return App.errorLog.filter(err => {
        const searchMatch = !App.filters.errorSearch ||
            err.resource?.toLowerCase().includes(App.filters.errorSearch.toLowerCase()) ||
            err.message?.toLowerCase().includes(App.filters.errorSearch.toLowerCase()) ||
            err.type?.toLowerCase().includes(App.filters.errorSearch.toLowerCase());

        const severityMatch = App.filters.severity === 'all' || err.severity === App.filters.severity;
        const typeMatch = App.filters.type === 'all' || err.type === App.filters.type;

        return searchMatch && severityMatch && typeMatch;
    });
}

function renderFixHistory() {
    const tbody = document.getElementById('fix-history-list');
    const fixed = App.errorLog.filter(e => e.fixed);

    if (fixed.length === 0) {
        tbody.innerHTML = `<tr class="empty-row"><td colspan="4">尚無修復記錄</td></tr>`;
        return;
    }

    tbody.innerHTML = fixed.slice(0, 20).map(err => `
        <tr>
            <td>${renderSeverityBadge(err.severity)}</td>
            <td><code>${escapeHtml(err.resource)}</code></td>
            <td><span class="msg-truncate">${escapeHtml(truncate(err.message))}</span></td>
            <td><span class="text-muted">${formatTime(err.fixedAt || err.timestamp)}</span></td>
        </tr>
    `).join('');
}

// ============================================================
// 錯誤類型分佈圖表
// ============================================================

function renderErrorChart() {
    const container = document.getElementById('chart-bars');
    const typeCounts = {};

    App.errorLog.forEach(err => {
        const type = err.type || 'UNKNOWN';
        typeCounts[type] = (typeCounts[type] || 0) + 1;
    });

    const sorted = Object.entries(typeCounts).sort((a, b) => b[1] - a[1]);
    const maxCount = sorted.length > 0 ? sorted[0][1] : 1;

    if (sorted.length === 0) {
        container.innerHTML = `<div style="text-align:center;color:var(--text-muted);padding:20px">尚無資料</div>`;
        return;
    }

    container.innerHTML = sorted.map(([type, count]) => {
        const pct = Math.max(4, Math.round((count / maxCount) * 100));
        const color = ERROR_TYPE_COLORS[type] || '#8b949e';
        const label = ERROR_TYPE_LABELS[type] || type;
        return `
            <div class="chart-bar-item">
                <span class="chart-bar-label">${escapeHtml(label)}</span>
                <div class="chart-bar-track">
                    <div class="chart-bar-fill" style="width:${pct}%;background:${color}"></div>
                </div>
                <span class="chart-bar-value">${count}</span>
            </div>
        `;
    }).join('');
}

// ============================================================
// 更新資源清單
// ============================================================

function updateResourceList(resourceList) {
    App.resourceList = resourceList || [];
    renderResourceList();
    document.getElementById('resource-count').textContent = `共 ${App.resourceList.length} 個資源`;
}

function renderResourceList() {
    const tbody = document.getElementById('resource-list');
    const filtered = filterResources();

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr class="empty-row"><td colspan="5">沒有符合條件的資源</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(res => `
        <tr>
            <td><code>${escapeHtml(res.name)}</code></td>
            <td>${renderStateBadge(res.state)}</td>
            <td>
                <span class="${res.restartCount > 0 ? 'text-mono' : 'text-muted'}" style="${res.restartCount >= 3 ? 'color:var(--severity-critical)' : ''}">
                    ${res.restartCount || 0} 次
                </span>
            </td>
            <td><span class="text-muted">${res.lastRestart || 'Never'}</span></td>
            <td>
                <button class="btn btn-warning btn-sm" onclick="restartResource('${escapeHtml(res.name)}')">
                    🔄 重啟
                </button>
            </td>
        </tr>
    `).join('');
}

function filterResources() {
    return App.resourceList.filter(res => {
        const searchMatch = !App.filters.resourceSearch ||
            res.name?.toLowerCase().includes(App.filters.resourceSearch.toLowerCase());
        const stateMatch = App.filters.resourceState === 'all' || res.state === App.filters.resourceState;
        return searchMatch && stateMatch;
    });
}

// ============================================================
// 錯誤詳情 Modal
// ============================================================

function openErrorModal(errorId) {
    const err = App.errorLog.find(e => e.id === errorId);
    if (!err) return;

    App.selectedErrorId = errorId;

    const body = document.getElementById('modal-body');
    body.innerHTML = `
        <div class="detail-grid">
            <div class="detail-item">
                <div class="detail-key">錯誤 ID</div>
                <div class="detail-value text-mono">#${escapeHtml(err.id)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-key">嚴重程度</div>
                <div class="detail-value">${renderSeverityBadge(err.severity)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-key">錯誤類型</div>
                <div class="detail-value">${escapeHtml(ERROR_TYPE_LABELS[err.type] || err.type)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-key">資源名稱</div>
                <div class="detail-value"><code>${escapeHtml(err.resource)}</code></div>
            </div>
            <div class="detail-item">
                <div class="detail-key">發生時間</div>
                <div class="detail-value">${formatTime(err.timestamp)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-key">修復狀態</div>
                <div class="detail-value">${renderFixBadge(err.fixed)}</div>
            </div>
        </div>
        <div style="margin-bottom:8px;font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px">錯誤訊息</div>
        <div class="detail-message">${escapeHtml(err.message || 'No message')}</div>
        ${err.fixedAt ? `<div style="margin-top:12px;font-size:12px;color:var(--accent-green)">✅ 修復時間: ${formatTime(err.fixedAt)}</div>` : ''}
    `;

    const fixBtn = document.getElementById('modal-fix-btn');
    fixBtn.style.display = err.fixed ? 'none' : 'inline-flex';

    document.getElementById('error-modal').classList.remove('hidden');
}

function closeErrorModal() {
    document.getElementById('error-modal').classList.add('hidden');
    App.selectedErrorId = null;
}

// ============================================================
// 操作函數
// ============================================================

function markFixed(errorId) {
    nuiCallback('markFixed', { id: errorId });
    showNotification('已標記為修復！', 'success');
}

function restartResource(resourceName) {
    if (!confirm(`確定要重啟資源 "${resourceName}" 嗎？`)) return;
    nuiCallback('restartResource', { resourceName });
    showNotification(`正在重啟資源: ${resourceName}`, 'info');
}

function updateLastUpdate() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('zh-TW');
    document.getElementById('last-update').textContent = `最後更新: ${timeStr}`;
}

// ============================================================
// 事件綁定
// ============================================================

function bindEvents() {
    // 導覽按鈕
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    // 關閉面板
    document.getElementById('close-btn').addEventListener('click', () => {
        nuiCallback('closePanel');
    });

    // 刷新按鈕
    document.getElementById('refresh-btn').addEventListener('click', () => {
        nuiCallback('refreshData');
        showNotification('正在刷新資料...', 'info');
    });

    // 清除日誌
    document.getElementById('clear-log-btn').addEventListener('click', () => {
        if (!confirm('確定要清除所有錯誤日誌嗎？此操作無法復原。')) return;
        nuiCallback('clearLog');
    });

    // 清除問題實體
    document.getElementById('clear-entities-btn').addEventListener('click', () => {
        if (!confirm('確定要清除所有問題實體嗎？')) return;
        nuiCallback('clearEntities');
        showNotification('正在清除問題實體...', 'info');
    });

    // 測試 Webhook
    document.getElementById('test-webhook-btn').addEventListener('click', () => {
        nuiCallback('testWebhook');
        showNotification('已發送測試 Webhook！', 'info');
    });

    // 重啟資源
    document.getElementById('restart-resource-btn').addEventListener('click', () => {
        const input = document.getElementById('restart-resource-input');
        const name = input.value.trim();
        if (!name) {
            showNotification('請輸入資源名稱！', 'warning');
            return;
        }
        restartResource(name);
        input.value = '';
    });

    // Modal 關閉
    document.getElementById('modal-close').addEventListener('click', closeErrorModal);
    document.getElementById('modal-close-btn').addEventListener('click', closeErrorModal);
    document.getElementById('error-modal').addEventListener('click', (e) => {
        if (e.target === document.getElementById('error-modal')) closeErrorModal();
    });

    // Modal 標記修復
    document.getElementById('modal-fix-btn').addEventListener('click', () => {
        if (App.selectedErrorId) {
            markFixed(App.selectedErrorId);
            closeErrorModal();
        }
    });

    // 搜尋過濾
    document.getElementById('error-search').addEventListener('input', (e) => {
        App.filters.errorSearch = e.target.value;
        renderErrorList();
    });

    document.getElementById('severity-filter').addEventListener('change', (e) => {
        App.filters.severity = e.target.value;
        renderErrorList();
    });

    document.getElementById('type-filter').addEventListener('change', (e) => {
        App.filters.type = e.target.value;
        renderErrorList();
    });

    document.getElementById('resource-search').addEventListener('input', (e) => {
        App.filters.resourceSearch = e.target.value;
        renderResourceList();
    });

    document.getElementById('resource-state-filter').addEventListener('change', (e) => {
        App.filters.resourceState = e.target.value;
        renderResourceList();
    });

    // Enter 鍵重啟資源
    document.getElementById('restart-resource-input').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            document.getElementById('restart-resource-btn').click();
        }
    });
}

// ============================================================
// FiveM NUI 訊息處理
// ============================================================

window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || !data.action) return;

    switch (data.action) {
        case 'open':
            document.getElementById('app').classList.remove('hidden');
            switchTab('dashboard');
            break;

        case 'close':
            document.getElementById('app').classList.add('hidden');
            break;

        case 'updateErrorLog':
            updateErrorLog(data.data);
            break;

        case 'updateStats':
            updateStats(data.data);
            break;

        case 'updateResourceList':
            updateResourceList(data.data);
            break;

        case 'newError':
            // 即時插入新錯誤
            if (data.data) {
                App.errorLog.unshift(data.data);
                if (App.errorLog.length > 500) App.errorLog.pop();
                renderDashboardErrors();
                renderErrorList();
                renderErrorChart();
                updateStats({
                    ...App.stats,
                    total: App.stats.total + 1,
                    [data.data.severity]: (App.stats[data.data.severity] || 0) + 1
                });
            }
            break;

        case 'logCleared':
            App.errorLog = [];
            updateErrorLog([]);
            updateStats({ total: 0, critical: 0, high: 0, medium: 0, low: 0, fixed: 0 });
            showNotification('錯誤日誌已清除！', 'success');
            break;

        case 'notification':
            showNotification(data.message, data.notifType || 'info');
            break;
    }
});

// ============================================================
// 初始化
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    bindEvents();

    // 開發模式預覽 (非 FiveM 環境)
    if (!window.GetParentResourceName) {
        console.log('[ErrorHandler] 開發模式啟動 - 載入測試資料');
        loadDevData();
    }
});

// ============================================================
// 開發模式測試資料
// ============================================================

function loadDevData() {
    document.getElementById('app').classList.remove('hidden');

    const mockErrors = [
        { id: '123456', type: 'LUA_RUNTIME', resource: 'esx_vehicleshop', message: "attempt to index a nil value (global 'ESX') stack traceback: esx_vehicleshop/client/main.lua:45", severity: 'high', timestamp: '2026-03-22 10:30:15', fixed: false },
        { id: '234567', type: 'RESOURCE_CRASH', resource: 'qb-inventory', message: '資源 [qb-inventory] 意外停止！重啟次數: 1/3', severity: 'critical', timestamp: '2026-03-22 10:28:42', fixed: true, fixedAt: '2026-03-22 10:29:00' },
        { id: '345678', type: 'DATABASE_ERROR', resource: 'oxmysql', message: "MySQL Error: Connection refused - ECONNREFUSED 127.0.0.1:3306", severity: 'critical', timestamp: '2026-03-22 10:25:10', fixed: false },
        { id: '456789', type: 'NETWORK_SYNC', resource: 'server', message: '玩家 [TestPlayer] (ID: 5) 因網路問題斷線: Timed out', severity: 'low', timestamp: '2026-03-22 10:20:05', fixed: true, fixedAt: '2026-03-22 10:20:05' },
        { id: '567890', type: 'LUA_RUNTIME', resource: 'es_extended', message: "stack overflow in function 'GetPlayerData' es_extended/server/main.lua:312", severity: 'high', timestamp: '2026-03-22 10:15:33', fixed: false },
        { id: '678901', type: 'ENTITY_ERROR', resource: 'qb-vehiclekeys', message: '玩家 Ped 實體不存在 (Entity sync error)', severity: 'medium', timestamp: '2026-03-22 10:10:22', fixed: false }
    ];

    const mockResources = [
        { name: 'es_extended', state: 'started', restartCount: 0, lastRestart: 'Never' },
        { name: 'qb-core', state: 'started', restartCount: 1, lastRestart: '2026-03-22 09:45:00' },
        { name: 'oxmysql', state: 'started', restartCount: 0, lastRestart: 'Never' },
        { name: 'qb-inventory', state: 'stopped', restartCount: 3, lastRestart: '2026-03-22 10:29:00' },
        { name: 'esx_vehicleshop', state: 'started', restartCount: 2, lastRestart: '2026-03-22 10:30:00' },
        { name: 'qb-vehiclekeys', state: 'starting', restartCount: 0, lastRestart: 'Never' }
    ];

    updateErrorLog(mockErrors);
    updateResourceList(mockResources);
    updateStats({ total: 6, critical: 2, high: 2, medium: 1, low: 1, fixed: 2 });
}
