-- ============================================================
-- FiveM Auto Error Handler - Resource Monitor & Auto-Fix
-- Author: Manus AI
-- ============================================================

local MonitoredResources = {}
local RestartQueue = {}

-- ============================================================
-- 資源狀態監控
-- ============================================================

--- 初始化資源監控清單
local function InitResourceList()
    local numResources = GetNumResources()
    for i = 0, numResources - 1 do
        local resName = GetResourceByFindIndex(i)
        if resName and resName ~= GetCurrentResourceName() then
            MonitoredResources[resName] = {
                name = resName,
                state = GetResourceState(resName),
                lastChecked = Utils.GetTimestamp()
            }
        end
    end
    print(string.format('^2[ErrorHandler]^7 已載入 %d 個資源到監控清單。', GetNumResources() - 1))
end

-- ============================================================
-- 資源啟動/停止事件監聽
-- ============================================================

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        InitResourceList()
        return
    end

    MonitoredResources[resourceName] = {
        name = resourceName,
        state = 'started',
        lastChecked = Utils.GetTimestamp()
    }

    -- 清除重啟佇列中的此資源 (代表已成功重啟)
    if RestartQueue[resourceName] then
        local errorData = Utils.FormatError(
            'RESOURCE_CRASH',
            resourceName,
            string.format('資源 [%s] 已成功自動重啟並恢復運行。', resourceName),
            'low'
        )
        errorData.fixed = true
        errorData.fixedAt = Utils.GetTimestamp()
        LogError(errorData)
        RestartQueue[resourceName] = nil
    end

    print(string.format('^2[ErrorHandler]^7 資源 [%s] 已啟動並加入監控。', resourceName))
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then return end

    if MonitoredResources[resourceName] then
        MonitoredResources[resourceName].state = 'stopped'
    end

    -- 判斷是否為非預期停止 (非手動停止)
    -- 若資源在未被明確停止的情況下停止，視為崩潰
    if not IsResourceInStopList(resourceName) then
        HandleResourceCrash(resourceName)
    end
end)

-- 手動停止清單 (避免誤判)
local ManualStopList = {}

function IsResourceInStopList(resourceName)
    if ManualStopList[resourceName] then
        ManualStopList[resourceName] = nil
        return true
    end
    return false
end

-- 手動停止資源指令 (管理員使用)
RegisterNetEvent('errorhandler:manualStopResource', function(resourceName)
    local src = source
    if not IsPlayerAdmin(src) then return end
    ManualStopList[resourceName] = true
    ExecuteCommand('stop ' .. resourceName)
end)

-- ============================================================
-- 資源崩潰處理
-- ============================================================

function HandleResourceCrash(resourceName)
    local restartInfo = GetResourceRestartInfo(resourceName)
    local severity = 'high'

    if restartInfo.count >= Config.AutoFix.MaxRestartAttempts then
        severity = 'critical'
    end

    local errorData = Utils.FormatError(
        'RESOURCE_CRASH',
        resourceName,
        string.format(
            '資源 [%s] 意外停止！重啟次數: %d/%d',
            resourceName,
            restartInfo.count,
            Config.AutoFix.MaxRestartAttempts
        ),
        severity
    )

    LogError(errorData)

    -- 自動重啟邏輯
    if Config.AutoFix.RestartCrashedResources then
        if restartInfo.count < Config.AutoFix.MaxRestartAttempts then
            -- 加入重啟佇列
            RestartQueue[resourceName] = true

            -- 冷卻後重啟
            SetTimeout(Config.AutoFix.RestartCooldown, function()
                local currentState = GetResourceState(resourceName)
                if currentState == 'stopped' or currentState == 'missing' then
                    print(string.format('^3[ErrorHandler]^7 正在自動重啟資源 [%s]... (第 %d 次)', resourceName, restartInfo.count + 1))
                    UpdateRestartRecord(resourceName)
                    ExecuteCommand('start ' .. resourceName)
                end
            end)
        else
            -- 超過最大重啟次數，發送嚴重警告
            local criticalError = Utils.FormatError(
                'RESOURCE_CRASH',
                resourceName,
                string.format(
                    '⚠️ 資源 [%s] 已達最大重啟次數上限 (%d 次)，需要人工介入！',
                    resourceName,
                    Config.AutoFix.MaxRestartAttempts
                ),
                'critical'
            )
            LogError(criticalError)
            print(string.format('^1[ErrorHandler]^7 ⚠️ 資源 [%s] 已超過最大重啟次數，停止自動修復！', resourceName))
        end
    end
end

-- ============================================================
-- 定期健康檢查
-- ============================================================

CreateThread(function()
    Wait(5000) -- 等待伺服器完全啟動
    InitResourceList()

    while true do
        Wait(Config.Monitor.CheckInterval)

        for resName, resData in pairs(MonitoredResources) do
            local currentState = GetResourceState(resName)

            -- 偵測狀態異常 (卡在 starting 或 stopping 過久)
            if currentState == 'starting' then
                -- 記錄可能卡住的資源
                if resData.state == 'starting' then
                    local stuckError = Utils.FormatError(
                        'RESOURCE_CRASH',
                        resName,
                        string.format('資源 [%s] 疑似卡在啟動狀態，可能發生錯誤。', resName),
                        'medium'
                    )
                    -- 避免重複記錄
                    if not resData.stuckReported then
                        LogError(stuckError)
                        resData.stuckReported = true
                    end
                end
            else
                resData.stuckReported = false
            end

            resData.state = currentState
            resData.lastChecked = Utils.GetTimestamp()
        end
    end
end)

-- ============================================================
-- 取得資源監控清單 (供 NUI 查詢)
-- ============================================================

RegisterNetEvent('errorhandler:getResourceList', function()
    local src = source
    if not IsPlayerAdmin(src) then return end

    local resourceList = {}
    for resName, resData in pairs(MonitoredResources) do
        local restartInfo = GetResourceRestartInfo(resName)
        table.insert(resourceList, {
            name = resName,
            state = GetResourceState(resName),
            restartCount = restartInfo.count,
            lastRestart = restartInfo.lastRestart
        })
    end

    -- 依名稱排序
    table.sort(resourceList, function(a, b) return a.name < b.name end)

    TriggerClientEvent('errorhandler:receiveResourceList', src, resourceList)
end)

-- ============================================================
-- 手動重啟資源 (管理員指令)
-- ============================================================

RegisterNetEvent('errorhandler:restartResource', function(resourceName)
    local src = source
    if not IsPlayerAdmin(src) then return end

    if not resourceName or resourceName == '' then return end
    if resourceName == GetCurrentResourceName() then
        TriggerClientEvent('errorhandler:notification', src, '無法重啟監控資源本身！', 'error')
        return
    end

    local state = GetResourceState(resourceName)
    if state == 'missing' then
        TriggerClientEvent('errorhandler:notification', src, '找不到資源: ' .. resourceName, 'error')
        return
    end

    print(string.format('^3[ErrorHandler]^7 管理員 [%s] 手動重啟資源 [%s]', GetPlayerName(tostring(src)), resourceName))
    ExecuteCommand('restart ' .. resourceName)

    local actionLog = Utils.FormatError(
        'RESOURCE_CRASH',
        resourceName,
        string.format('管理員 [%s] 手動重啟了資源 [%s]。', GetPlayerName(tostring(src)), resourceName),
        'low'
    )
    actionLog.fixed = true
    LogError(actionLog)

    TriggerClientEvent('errorhandler:notification', src, '已重啟資源: ' .. resourceName, 'success')
end)

-- ============================================================
-- 自動清除問題實體
-- ============================================================

RegisterNetEvent('errorhandler:clearProblematicEntities', function()
    local src = source
    if not IsPlayerAdmin(src) then return end

    if not Config.AutoFix.ClearProblematicEntities then
        TriggerClientEvent('errorhandler:notification', src, '自動清除實體功能已停用。', 'warning')
        return
    end

    -- 觸發客戶端執行實體清除
    TriggerClientEvent('errorhandler:doEntityCleanup', src)
    print(string.format('^3[ErrorHandler]^7 管理員 [%s] 觸發了實體清除。', GetPlayerName(tostring(src))))
end)
