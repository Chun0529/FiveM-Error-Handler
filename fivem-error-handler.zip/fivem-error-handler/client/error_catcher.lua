-- ============================================================
-- FiveM Auto Error Handler - Client Error Catcher
-- Author: Manus AI
-- ============================================================

-- ============================================================
-- Lua 執行錯誤捕捉 (使用 pcall/xpcall 包裝)
-- ============================================================

--- 安全執行函數，捕捉並回報錯誤
--- @param func function 要執行的函數
--- @param resourceName string 資源名稱
--- @param ... any 傳遞給函數的參數
--- @return boolean, any
function SafeCall(func, resourceName, ...)
    local ok, err = xpcall(func, function(e)
        -- 取得完整的錯誤堆疊追蹤
        return debug.traceback(e, 2)
    end, ...)

    if not ok then
        -- 回報錯誤到伺服器
        TriggerServerEvent('errorhandler:reportClientError', tostring(err), resourceName or GetCurrentResourceName())
    end

    return ok, err
end

-- ============================================================
-- 監聽全域 Lua 錯誤 (透過 AddEventHandler 包裝)
-- ============================================================

-- 捕捉 Citizen.CreateThread 中的錯誤
local originalCreateThread = CreateThread
CreateThread = function(func)
    originalCreateThread(function()
        local ok, err = xpcall(func, function(e)
            return debug.traceback(e, 2)
        end)

        if not ok then
            local errMsg = tostring(err)
            -- 過濾掉無意義的錯誤
            if not errMsg:find('attempt to index a nil value') or true then
                TriggerServerEvent('errorhandler:reportClientError', errMsg, GetCurrentResourceName())
            end
        end
    end)
end

-- ============================================================
-- 網路同步錯誤偵測
-- ============================================================

if Config.Monitor.LogNetworkErrors then
    -- 偵測實體不存在的錯誤
    CreateThread(function()
        while true do
            Wait(10000) -- 每 10 秒檢查一次

            -- 檢查本地玩家 Ped 是否有效
            local playerPed = PlayerPedId()
            if not DoesEntityExist(playerPed) then
                TriggerServerEvent('errorhandler:reportClientError',
                    '玩家 Ped 實體不存在 (Entity sync error)',
                    GetCurrentResourceName()
                )
            end
        end
    end)
end

-- ============================================================
-- 實體清除功能
-- ============================================================

RegisterNetEvent('errorhandler:doEntityCleanup', function()
    -- 清除所有無效的本地實體
    local cleanedCount = 0

    -- 清除無效車輛
    local vehicles = GetGamePool('CVehicle')
    for _, vehicle in ipairs(vehicles) do
        if DoesEntityExist(vehicle) and IsEntityAMissionEntity(vehicle) then
            local netId = NetworkGetNetworkIdFromEntity(vehicle)
            if netId == 0 or not NetworkDoesEntityExistWithNetworkId(netId) then
                DeleteEntity(vehicle)
                cleanedCount = cleanedCount + 1
            end
        end
    end

    -- 清除無效 Ped
    local peds = GetGamePool('CPed')
    for _, ped in ipairs(peds) do
        if DoesEntityExist(ped) and not IsPedAPlayer(ped) then
            local netId = NetworkGetNetworkIdFromEntity(ped)
            if netId == 0 or not NetworkDoesEntityExistWithNetworkId(netId) then
                DeleteEntity(ped)
                cleanedCount = cleanedCount + 1
            end
        end
    end

    -- 清除無效物件
    local objects = GetGamePool('CObject')
    for _, obj in ipairs(objects) do
        if DoesEntityExist(obj) then
            local netId = NetworkGetNetworkIdFromEntity(obj)
            if netId == 0 or not NetworkDoesEntityExistWithNetworkId(netId) then
                DeleteEntity(obj)
                cleanedCount = cleanedCount + 1
            end
        end
    end

    print(string.format('[ErrorHandler] 已清除 %d 個問題實體。', cleanedCount))
    TriggerServerEvent('errorhandler:reportServerError',
        string.format('管理員觸發實體清除，共清除 %d 個無效實體。', cleanedCount),
        'entity_cleanup'
    )
end)
