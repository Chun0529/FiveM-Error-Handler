-- ============================================================
-- FiveM Auto Error Handler - Client NUI Helper
-- Author: Manus AI
-- ============================================================

-- ============================================================
-- 鍵盤快捷鍵設定
-- ============================================================

-- 註冊開啟面板的按鍵 (F8 預設，可在 config 修改)
RegisterKeyMapping(
    Config.Permissions.CommandName,
    '開啟錯誤監控面板',
    'keyboard',
    'F8'
)

-- ============================================================
-- 遊戲內通知輔助函數
-- ============================================================

--- 顯示遊戲內通知
--- @param message string 通知訊息
--- @param notifType string 通知類型 (success/error/warning/info)
function ShowNotification(message, notifType)
    local prefix = ''
    if notifType == 'success' then prefix = '~g~'
    elseif notifType == 'error' then prefix = '~r~'
    elseif notifType == 'warning' then prefix = '~y~'
    else prefix = '~b~'
    end

    SetNotificationTextEntry('STRING')
    AddTextComponentString(prefix .. '[ErrorHandler]~w~ ' .. message)
    DrawNotification(false, true)
end

-- ============================================================
-- 初始化訊息
-- ============================================================

AddEventHandler('onClientResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        Wait(1000)
        ShowNotification('錯誤監控系統已啟動！輸入 /' .. Config.Permissions.CommandName .. ' 開啟面板。', 'success')
    end
end)
